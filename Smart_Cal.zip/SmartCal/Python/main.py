from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.image import Image 
from kivy.uix.widget import Widget
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.togglebutton import ToggleButton
from kivy.uix.boxlayout import BoxLayout
from kivy.clock import Clock
from kivy.graphics.texture import Texture
from kivy.graphics import Rectangle
from kivy.uix.relativelayout import RelativeLayout

import numpy as np
from sklearn.linear_model import LinearRegression

from kivy.uix.textinput import TextInput

from pyzbar import pyzbar
import webbrowser
import cv2
import sqlite3

import matplotlib.pyplot as plt
from matplotlib.figure import Figure
import io

from datetime import datetime
import calendar

# Create global variables, for storing and displaying barcodes
outputtext=''
weblink=''
leb=Label(text=outputtext,size_hint_y=None,height='48dp',font_size='45dp')
found = set()       # this will not allow duplicate barcode scans to be stored
togglflag=True

screen_width = 720
screen_height = 1280

scanner_button_width = '150dp'
scanner_button_height = '150dp'

output_screen_width = 500
output_screen_height = 1000

scanner_button_x = 410  # Adjust the initial x-position as needed
scanner_button_y = 0  # Adjust the initial y-position as needed

record_button_x = 320
record_button_y = 650

record_button_width = '50dp'
record_button_height = '50dp'

database_path="C:\\Users\\user\\Desktop\\SmartCal\\Python\\smartcal.db"


class HomeScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'

        # Display the image on the homepage
        image = Image(source='homepage_image.png')  # Update with your image filename
        self.add_widget(image)

        # Add a button to switch to the scanner page
        scanner_button = Button(
            #text='Start Scanner',
            on_press=self.switch_to_scanner,
            size_hint=(None, None),
            size=(scanner_button_width, scanner_button_height),  # Use the variables here
            pos=(scanner_button_x, scanner_button_y)
        )
        scanner_button.background_normal = 'scanner_button_image.png'
        self.add_widget(scanner_button)
        
        # Add a button to switch to the record screen
        record_button = Button(
            text='History',
            on_press=self.switch_to_record,
            size_hint=(None, None),
            size=(record_button_width, record_button_height),
            pos=(record_button_x, record_button_y)  # Adjust the position as needed
        )
        record_button.background_normal = 'background.png'  # Replace with your image
        self.add_widget(record_button)

    def switch_to_scanner(self, instance):
        self.manager.current = 'main'
        
    def switch_to_record(self, instance):
        self.manager.current = 'record'

        
class MainScreen(BoxLayout):
    # first screen that is displayed when program is run
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.orientation='vertical'  # vertical placing of widgets
        
        self.cam=cv2.VideoCapture(0)    # start OpenCV camera
        self.cam.set(3,screen_width)        # set resolution of camera
        self.cam.set(4,screen_height)
        self.img=Image()        # Image widget to display frames
        
        # create Toggle Button for pause and play of video stream
        self.togbut=ToggleButton(text='Pause',group='camstart',state='down',size_hint_y=None,height='48dp',on_press=self.change_state)
        self.but=Button(text='Stop',size_hint_y=None,height='48dp',on_press=self.stop_stream)
        self.add_widget(self.img)
        self.add_widget(self.togbut)
        self.add_widget(self.but)
        Clock.schedule_interval(self.update,1.0/30)     # update for 30fps
        
                
    # update frame of OpenCV camera
    def update(self,dt):
        if togglflag:
            ret, frame = self.cam.read()    # retrieve frames from OpenCV camera
            
            if ret:
                buf1=cv2.flip(frame,0)      # convert it into texture 
                buf=buf1.tostring()
                image_texture=Texture.create(size=(frame.shape[1],frame.shape[0]),colorfmt='bgr')
                image_texture.blit_buffer(buf,colorfmt='bgr',bufferfmt='ubyte')
                self.img.texture=image_texture  # display image from the texture
                
                barcodes = pyzbar.decode(frame)     # detect barcode from image
                for barcode in barcodes:
                    (x, y, w, h) = barcode.rect
                    cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)
                    barcodeData = barcode.data.decode("utf-8")
                    barcodeType = barcode.type
                    weblink=barcodeData
                    #main_app.secondsc.displayCal(weblink)         ############################################
                    print(weblink)
                    print(barcodeData)
                    text = "{} ({})".format(barcodeData, barcodeType)
                    cv2.putText(frame, text, (x, y - 10),cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
                    if barcodeData not in found:    # check if detected barcode is a duplicate
                        outputtext=text
                        leb.text=outputtext         # display the barcode details
                        found.add(barcodeData)
                        self.change_screen(weblink)
                
                key = cv2.waitKey(1) & 0xFF
                if key == ord("q"):
                    cv2.destroyAllWindows()
                    exit(0)
                    
         
    # change state of toggle button
    def change_state(self,*args):
        global togglflag
        if togglflag:
            self.togbut.text='Play'
            togglflag=False
        else:
            self.togbut.text='Pause'
            togglflag=True
            
            
    def stop_stream(self,*args):
        self.cam.release()  # stop camera
        
    def change_screen(self,weblink):
        main_app.sm.current='second'    # once barcode is detected, switch to second screen
        main_app.secondsc.displayCal(weblink)
    
class SecondScreen(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'

        # Initialize properties for background attributes
        self.background_source = 'background.png'
        self.background_pos = (250, 0)
        self.background_size = (output_screen_width,output_screen_height)

        # Display the background image
        with self.canvas.before:
            self.background_rect = Rectangle(
                source=self.background_source,
                pos=self.background_pos,
                size=self.background_size
            )
        
        # Create a BoxLayout to organize the content vertically
        content_layout = RelativeLayout()
        
        # Add a button for storing data
        self.store_button = Button(
            text='Store Data',
            size_hint=(None, None),
            size=(200, 48),
            pos = (400,200),
            font_size='20sp',
            on_press=self.store_data
        )
        content_layout.add_widget(self.store_button)

        # Add the output label
        self.lab1 = Label(
            text='Output:',
            size_hint=(None, None),
            size=(200, 50),  # Set the size as needed
            pos = (350,80),
            font_size='20sp'
        )
        content_layout.add_widget(self.lab1)

        # Add the content layout to the SecondScreen
        self.add_widget(content_layout)
        
        
    def store_data(self, instance):
        if hasattr(self, 'weblink'):
            weblink = self.weblink  # Use the stored weblink value
            print("Working")  # Print a message to check if the method is invoked
            conn = sqlite3.connect("smartcal.db")
            cursor = conn.cursor()
            
            # Fetch the details of the current product
            cursor.execute('SELECT calories, name, price FROM foodinfo WHERE barcode = ?', (weblink,))
            current_product = cursor.fetchone()
            print(weblink,"working")
            
            # Check if a product with the given barcode was found
            if current_product:
                print("Product Found")  # Print a message to indicate that a product was found
                current_calories, current_name, current_price = current_product
                
                # Insert data into the calorieintake table
                cursor.execute('INSERT INTO calorieintake (barcode, calories, date) VALUES (?, ?, ?)',
                            (weblink, current_calories, datetime.now().date()))
                conn.commit()
                conn.close()
                self.lab1.text += "\nData Stored Successfully!"  # Update the label to indicate data storage
            else:
                print("Product Not Found")  # Print a message if no product was found with the barcode

            
    def update_background(self, source=None, pos=None, size=None):
        # Update the background image attributes
        if source:
            self.background_source = source
        if pos:
            self.background_pos = pos
        if size:
            self.background_size = size

        # Update the background image
        self.background_rect.source = self.background_source
        self.background_rect.pos = self.background_pos
        self.background_rect.size = self.background_size

    def displayCal(self, weblink):
        relative_layout = RelativeLayout()
        self.weblink = weblink
        conn = sqlite3.connect("smartcal.db")
        cursor = conn.cursor()

        # Fetch the details of the current product
        cursor.execute('SELECT calories, name, price FROM foodinfo WHERE barcode = ?', (weblink,))
        current_product = cursor.fetchone()

        if current_product:
            current_calories, current_name, current_price = current_product

            # Fetch products with the same price but lower calories
            cursor.execute('SELECT calories, name, price FROM foodinfo WHERE price = ? AND calories < ? ORDER BY calories LIMIT 3',
                        (current_price, current_calories))
            items_data = cursor.fetchall()
            
            # Create a label to display the current product's information
            current_info_label = Label(
                text=f'Name: {current_name}\nCalories: {current_calories}\nPrice: {current_price}',
                size_hint=(None, None),
                size=(300, 200),  # Set size as needed
                #pos_hint={'center_x': 0.5, 'center_y': 0.6},  # Adjust position as needed
                pos=(350,300),
                font_size='20sp'
            )
            
            relative_layout.add_widget(current_info_label)
            
            # Create labels to display other products' information
            y_offset = 0.4  # Adjust the initial y-position as needed
            posOffset = (380,200)
            color_code = '#5AA75A'
            for item in items_data:
                calories, name, price = item
                item_info_label = Label(
                    text=f'[color={color_code}]Name: {name}\nCalories: {calories}\nPrice: {price}[/color]',
                    size_hint=(None, None),
                    size=(300, 200),  # Set size as needed
                    #pos_hint={'center_x': 0.5, 'center_y': y_offset},  # Adjust position as needed
                    pos=posOffset,
                    font_size='20sp'
                )
                item_info_label.markup = True
                relative_layout.add_widget(item_info_label)
                posOffset = (posOffset[0], posOffset[1] - 100)
                y_offset -= 0.15 # Adjust the vertical spacing as needed

            # Add the RelativeLayout to the SecondScreen
            self.add_widget(relative_layout)

            conn.close()
            
        else:
            self.lab1.text = 'No information found for this barcode.'
            self.change_screen(weblink)
        

    
    def change_screen(self,weblink):
        main_app.thirdsc.set_weblink_input(weblink)
        main_app.sm.current='third'           
        
class ThirdScreen(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        
        # Initialize properties for background attributes
        self.background_source = 'background.png'
        self.background_pos = (250, 0)
        self.background_size = (output_screen_width,output_screen_height)

        # Display the background image
        with self.canvas.before:
            self.background_rect = Rectangle(
                source=self.background_source,
                pos=self.background_pos,
                size=self.background_size
            )

        # Text input for weblink value
        self.weblink_input = TextInput(
            hint_text='Enter weblink value',
            multiline=False,
            size_hint=(None, None),
            size=(200, 48),  # Set size directly
            pos_hint={'center_x': 0.5, 'center_y': 0.4},
            font_size='20sp'
        )
        self.add_widget(self.weblink_input)
        
        # Text inputs for user inputs
        self.name_input = TextInput(
            hint_text='Enter name',
            multiline=False,
            size_hint=(None, None),
            size=(200, 48),  # Set size directly
            pos_hint={'center_x': 0.5, 'center_y': 0.4},
            font_size='20sp'
        )
        self.add_widget(self.name_input)

        self.calories_input = TextInput(
            hint_text='Enter calories',
            multiline=False,
            size_hint=(None, None),
            size=(200, 48),  # Set size directly
            pos_hint={'center_x': 0.5, 'center_y': 0.4},
            font_size='20sp'
        )
        self.add_widget(self.calories_input)

        self.price_input = TextInput(
            hint_text='Enter price',
            multiline=False,
            size_hint=(None, None),
            size=(200, 48),  # Set size directly
            pos_hint={'center_x': 0.5, 'center_y': 0.4},
            font_size='20sp'
        )
        self.add_widget(self.price_input)

        # Button to save data to the database
        self.save_button = Button(
            text='Upload',
            size_hint=(None, None),
            size=(200, 48),  # Set size directly
            pos_hint={'center_x': 0.5, 'center_y': 0.4},
            font_size='20sp',
            on_press=self.save_to_database
        )
        self.add_widget(self.save_button)
        
    def set_weblink_input(self, weblink):
        self.weblink_input.text = weblink

    def save_to_database(self, instance):
        # Get values from text inputs
        weblink = self.weblink_input.text
        name = self.name_input.text
        calories = self.calories_input.text
        price = self.price_input.text
        
        if not weblink or not name or not calories or not price:
            error_message = "Please fill in all the fields."
        
        else:
            # Insert data into the database (replace with your database logic)
            conn = sqlite3.connect(database_path)
            cursor = conn.cursor()
            cursor.execute('INSERT INTO foodinfo (barcode, name, calories, price) VALUES (?, ?, ?, ?)',
                        (weblink, name, calories, price))
            conn.commit()
            conn.close()

            # Clear text inputs after saving
            self.weblink_input.text = ''
            self.name_input.text = ''
            self.calories_input.text = ''
            self.price_input.text = ''

class RecordScreen(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'

        # Initialize properties for background attributes
        self.background_source = 'background.png'
        self.background_pos = (250, 0)
        self.background_size = (output_screen_width, output_screen_height)

        # Display the background image
        with self.canvas.before:
            self.background_rect = Rectangle(
                source=self.background_source,
                pos=self.background_pos,
                size=self.background_size
            )

        # Text input for total calorie goal
        self.total_calorie_goal_input = TextInput(
            hint_text='Enter total calorie goal',
            multiline=False,
            size_hint=(None, None),
            size=(250, 48),
            pos_hint={'center_x': 0.5, 'center_y': 0.4},
            font_size='20sp'
        )
        self.add_widget(self.total_calorie_goal_input)

        # Button to calculate and compare total calories
        calculate_button = Button(
            text='Calculate & Compare',
            size_hint=(None, None),
            size=(250, 48),
            pos_hint={'center_x': 0.5, 'center_y': 0.4},
            font_size='20sp'
        )
        calculate_button.bind(on_press=self.calculate_and_compare)
        self.add_widget(calculate_button)

        # Label to display the daily sum of calories
        self.daily_calories_label = Label(
            text='',
            size_hint=(None, None),
            size=(200, 48),
            pos_hint={'center_x': 0.5, 'center_y': 0.4},
            font_size='20sp'
        )
        self.add_widget(self.daily_calories_label)

    def calculate_and_compare(self, instance):
        # Get the total calorie goal from the input field
        total_goal = float(self.total_calorie_goal_input.text)

        # Calculate the daily sum of calories from the calorieintake table (replace with your logic)
        conn = sqlite3.connect(database_path)
        cursor = conn.cursor()
        cursor.execute('SELECT date, SUM(calories) FROM calorieintake GROUP BY date')
        daily_calories_data = cursor.fetchall()
        conn.close()

        # Calculate the estimated end-of-week total calories using linear regression (replace with your logic)
        # You can use libraries like scikit-learn for linear regression

        # Call the update_calories_info method of the ResultScreen
        main_app.resultsc.update_calories_info(daily_calories_data, total_goal)

        # Change the screen to the ResultScreen
        self.change_screen()            
    
    def change_screen(self):
        main_app.sm.current='result'
        
# Define the ResultScreen class
class ResultScreen(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        
        # Create instance variables
        self.daily_calories_data = []
        self.total_goal = 0

        # Initialize properties for background attributes
        self.background_source = 'background.png'
        self.background_pos = (250, 0)
        self.background_size = (output_screen_width,output_screen_height)

        # Display the background image
        with self.canvas.before:
            self.background_rect = Rectangle(
                source=self.background_source,
                pos=self.background_pos,
                size=self.background_size
            )

    def update_calories_info(self, daily_calories_data, total_goal):
        self.daily_calories_data = daily_calories_data
        self.total_goal = total_goal
        self.display_calories_info()

    def display_calories_info(self):
        # Create a RelativeLayout to position the Label
        relative_layout = RelativeLayout()

        # Display the daily sum of calories with day names and dates
        label = Label(
            text="Daily Calories Summary:\n",
            size_hint=(None, None),
            font_size='20sp'
        )
        color_code = '#5AA75A'
        for date, daily_sum in self.daily_calories_data:
            # Convert the date string to a datetime object
            date_obj = datetime.strptime(date, '%Y-%m-%d')
            # Format the date as 'Day, Month Day, Year' (e.g., 'Tuesday, Oct 4, 2023')
            formatted_date = date_obj.strftime('%A, %b %d, %Y')
            label.text += f"{formatted_date}: [color={color_code}]{daily_sum}[/color]\n"
            label.markup = True

        # Set the position of the Label within the RelativeLayout
        label.pos = (450, 600)  # Adjust the position as needed

        # Add the Label to the RelativeLayout
        relative_layout.add_widget(label)

        # Calculate the average daily calorie intake
        num_days = len(self.daily_calories_data)
        total_calories = sum(daily_sum for date, daily_sum in self.daily_calories_data)
        average_daily_calories = total_calories / num_days

        # Predict 7-day total calories
        num_days_to_predict = 7
        predicted_total_calories = average_daily_calories * num_days_to_predict

        # Display the predicted total calories
        color_code = '#5AA75A'
        prediction_label = Label(
            text=f"Predicted [color={color_code}]{num_days_to_predict}[/color]-Day Total Calories: [color={color_code}]{predicted_total_calories:.2f}[/color]",
            size_hint=(None, None),
            font_size='20sp',
            pos=(450, 500)  # Adjust the position as needed
        )
        prediction_label.markup = True

        # Add the prediction label to the RelativeLayout
        relative_layout.add_widget(prediction_label)

        # Calculate the recommended daily calorie intake to meet the goal
        color_code = '#5AA75A'
        remaining_days = num_days_to_predict - num_days
        if remaining_days > 0:
            recommended_daily_calories = (self.total_goal - total_calories) / remaining_days
            # Split the text into three lines
            recommendation_text = (
                f"Recommended Daily Calorie Intake",
                f"for [color={color_code}]{remaining_days}[/color] Remaining Days:",
                f"for [color={color_code}]{recommended_daily_calories:.2f}[/color] calories per day"
            )
            recommendation_label = Label(
                text='\n'.join(recommendation_text),  # Display in three lines
                size_hint=(None, None),
                font_size='20sp',
                pos=(450, 400)  # Adjust the position as needed
            )
        else:
            recommendation_label = Label(
                text=f"You have already met your total goal.",
                size_hint=(None, None),
                font_size='20sp',
                pos=(450, 400)  # Adjust the position as needed
            )
        recommendation_label.markup = True

        # Add the recommendation label to the RelativeLayout
        relative_layout.add_widget(recommendation_label)
    
        # Add the graph layout to the ResultScreen
        self.add_widget(relative_layout)

        # Create a Figure for the line graph
        fig = Figure(facecolor='#FFC56C')
        ax = fig.add_subplot(111)
        
        # Set the background color of the subplot
        ax.set_facecolor('#f2f2f2')  # Use the desired color code or name
        ax.spines['top'].set_color('orange')  # Change the top border color to gray or any desired color
        ax.spines['bottom'].set_color('orange')  # Change the bottom border color to gray or any desired color
        ax.spines['left'].set_color('orange')  # Change the left border color to gray or any desired color
        ax.spines['right'].set_color('orange')  # Change the right border color to gray or any desired color

        dates = [datetime.strptime(date, '%Y-%m-%d') for date, _ in self.daily_calories_data]
        day_names = [calendar.day_abbr[date.weekday()] for date in dates]
        daily_sums = [daily_sum for _, daily_sum in self.daily_calories_data]

        ax.plot(day_names, daily_sums, marker='o', linestyle='-')
        ax.set_xlabel('Day of the Week')
        ax.set_ylabel('Calories')
        ax.set_title('Daily Calorie Intake')
        ax.grid(True)
        
        # Save the graph as an image (e.g., PNG)
        graph_image_path = 'graph_image.png'
        fig.savefig(graph_image_path)

        # Create an Image widget to display the graph
        graph_image = Image(source=graph_image_path, size_hint=(None, None), size=(400, 300))

        # Position the graph image within the ResultScreen
        graph_image.pos = (300, 0)  # Adjust the position as needed

        # Add the graph image to the relative_layout
        relative_layout.add_widget(graph_image)
        
                       
class TestApp(App):
    def build(self):
        self.sm = ScreenManager()

        # Add the home screen
        home_screen = HomeScreen(name='home')
        self.sm.add_widget(home_screen)

        # Add the main and second screens as before
        self.mainsc = MainScreen()
        main_screen = Screen(name='main')
        main_screen.add_widget(self.mainsc)
        self.sm.add_widget(main_screen)

        self.secondsc = SecondScreen()
        second_screen = Screen(name='second')
        second_screen.add_widget(self.secondsc)
        self.sm.add_widget(second_screen)

        # Add the third screen
        self.thirdsc = ThirdScreen()
        third_screen = Screen(name='third')
        third_screen.add_widget(self.thirdsc)
        self.sm.add_widget(third_screen)
        
        # Add the record screen
        self.recordsc = RecordScreen()
        record_screen = Screen(name='record')
        record_screen.add_widget(self.recordsc)
        self.sm.add_widget(record_screen)
        
        # Add the ResultScreen
        self.resultsc = ResultScreen()
        result_screen = Screen(name='result')
        result_screen.add_widget(self.resultsc)
        self.sm.add_widget(result_screen)

        return self.sm


if __name__ == '__main__':
    main_app=TestApp()
    main_app.run()
    cv2.destroyAllWindows()        
