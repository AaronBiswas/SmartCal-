import sqlite3
from statistics import mean, median, mode

conn = sqlite3.connect('smartcal.db')

def impute_missing_values(db_name, table_name):
    # Connect to the database
    conn = sqlite3.connect(db_name)

    # Create a cursor object to execute SQL commands
    cursor = conn.cursor()

    # Define a function to impute missing values with the mean for numeric columns
    def impute_numeric(column_name, data_type):
        query = f"UPDATE {table_name} SET {column_name} = ? WHERE {column_name} IS NULL"
        values = []

        cursor.execute(f"SELECT {column_name} FROM {table_name} WHERE {column_name} IS NOT NULL")
        for row in cursor.fetchall():
            values.append(row[0])

        if data_type == 'REAL':
            imputed_value = mean(values)
        elif data_type == 'INTEGER':
            imputed_value = int(mean(values))

        cursor.execute(query, (imputed_value,))
        conn.commit()

    # Impute missing values for each column
    impute_numeric('calories', 'REAL')
    impute_numeric('price', 'REAL')

    # Close the cursor and the database connection
    cursor.close()
    conn.close()

#impute_missing_values('smartcal.db', 'foodinfo')
cursor = conn.cursor()

delete_query = "DELETE FROM foodinfo WHERE barcode IS NULL OR calories IS NULL OR name IS NULL OR price IS NULL"

cursor.execute(delete_query)

conn.commit()

cursor.close()
conn.close()
