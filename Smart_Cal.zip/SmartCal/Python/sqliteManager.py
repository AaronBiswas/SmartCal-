import sqlite3

conn = sqlite3.connect("smartcal.db")

# Creating the table
#conn.execute('''
#    CREATE TABLE calorieintake (
#        id INTEGER PRIMARY KEY AUTOINCREMENT,
#        barcode INTEGER,
#        calories INTEGER,
#        date DATE
#    )
#''')
#
#conn.close()

#insert
ins='''
    INSERT INTO calorieintake (barcode, calories, date) VALUES
        (8901021000011,110,'2023-10-04')
    '''
conn.execute(ins)
conn.commit()

ins='''
    INSERT INTO calorieintake (barcode, calories, date) VALUES
        (8901021000011,110,'2023-10-04')
    '''
conn.execute(ins)
conn.commit()

ins='''
    INSERT INTO calorieintake (barcode, calories, date) VALUES
        (8901023000009,230,'2023-10-04')
    '''
conn.execute(ins)
conn.commit()

ins='''
    INSERT INTO calorieintake (barcode, calories, date) VALUES
        (8901029000015,110,'2023-10-05')
    '''
conn.execute(ins)
conn.commit()

ins='''
    INSERT INTO calorieintake (barcode, calories, date) VALUES
        (8901036000004,290,'2023-10-05')
    '''
conn.execute(ins)
conn.commit()

ins='''
    INSERT INTO calorieintake (barcode, calories, date) VALUES
        (8901110010039,120,'2023-10-06')
    '''
conn.execute(ins)
conn.commit()

ins='''
    INSERT INTO calorieintake (barcode, calories, date) VALUES
        (8901110010085,80,'2023-10-07')
    '''
conn.execute(ins)
conn.commit()

ins='''
    INSERT INTO calorieintake (barcode, calories, date) VALUES
        (8901110010109,389,'2023-10-08')
    '''
conn.execute(ins)
conn.commit()

ins='''
    INSERT INTO calorieintake (barcode, calories, date) VALUES
        (8901110010092,371,'2023-10-09')
    '''
conn.execute(ins)
conn.commit()

conn.close()

#insert
#ins='''
#    insert into foodinfo(barcode,calories,name,price) VALUES
#        (8008,120,"test",10)
#    '''
#conn.execute(ins)
#conn.commit()
#conn.close()



#import sqlite3
#
## Connect to the database
#conn = sqlite3.connect('smartcal.db')
#
## Get the barcode value
#val = 8901719122217
#
## Execute a SQL query to select all rows from the foodinfo table where the barcode matches the given value
#data = conn.execute("SELECT * FROM foodinfo where barcode=?", (val,))
#
## Print the results of the query
#for row in data:
#    print(row[0], "      ", row[1], "   ", row[2], row[3])
#
## Close the database connection
#conn.close()